-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: health
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `nurse`
--

DROP TABLE IF EXISTS `nurse`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `nurse` (
  `Fname` text,
  `MI` text,
  `Lname` text,
  `Employee ID` int DEFAULT NULL,
  `First Name` text,
  `Middle Initial` text,
  `Last Name` text,
  `Age` int DEFAULT NULL,
  `Gender` text,
  `Phone #` text,
  `Address` text,
  `Username` text,
  `Password` text,
  `idnurse` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`idnurse`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `nurse`
--

LOCK TABLES `nurse` WRITE;
/*!40000 ALTER TABLE `nurse` DISABLE KEYS */;
INSERT INTO `nurse` VALUES ('Austin','t','Shea',101,'Austin','X','Shea',30,'Male','8519201766','76987 Andrew Place Suite 422\nWest Jared, ND 55254','austin.shea','H91Fp%h0@J',1),('Allison','M','Hamilton',102,'Allison','K','Hamilton',27,'Male','807-401-2259','0392 Justin Ramp\nHowardmouth, DE 16970','allison.hamilton','JD0dR23h^L',2),('Makayla','C','Martin',103,'Makayla','K','Martin',23,'Male','(894)684-4514','8280 Nolan Burg Apt. 354\nSouth Nathan, NC 60992','makayla.martin',')99XC6ilPK',3),('Rachel','R','Pruitt',104,'Rachel','q','Pruitt',22,'Male','599-959-1160x370','3447 Davis Ramp\nHernandeztown, IN 08075','rachel.pruitt','_OyDTk&n1O',4),('Casey','N','Washington',105,'Casey','b','Washington',29,'Male','296-664-3317x46501','428 Perry Haven Suite 966\nHillton, KY 31511','casey.washington','YGb5O7vGz$',5),('James','A','Sherman',106,'James','k','Sherman',30,'Male','2814474964','8197 Michael Lodge Apt. 805\nValdezville, SD 26765','james.sherman','#NAME?',6),('Maria','O','Shaw',107,'Maria','s','Shaw',58,'Female','001-520-845-0406x275','93282 Monica Ford\nDavidfurt, CT 11348','maria.shaw','$EwSONg$e7',7),('Lisa','e','Adams',108,'Lisa','s','Adams',45,'Male','(241)772-0949x990','703 Cook Hills\nNew Davidmouth, SD 96765','lisa.adams','7!5gS8FqSL',8),('Thomas','O','Chandler',109,'Thomas','X','Chandler',39,'Female','+1-687-895-1076x99566','615 Logan Path Apt. 820\nNorth Chelseaport, OK 01495','thomas.chandler','(6SzHbBu#2',9),('Jacqueline','l','Wilson',110,'Jacqueline','d','Wilson',29,'Female','(268)749-8773x323','8899 Miller Run Suite 929\nSophiaview, CT 13548','jacqueline.wilson','h$v0miFgaz',10),('Cassandra','L','Jarvis',111,'Cassandra','I','Jarvis',34,'Male','282-683-9268','PSC 4425, Box 2412\nAPO AA 35139','cassandra.jarvis','Tb)x6CWp^0',11),('Robert','G','Sanchez',112,'Robert','y','Sanchez',41,'Female','894.833.8872','44862 Bullock Mission Apt. 873\nPort Joseph, DE 98990','robert.sanchez','$8#4rNDkUj',12),('Tammy','o','Rodriguez',113,'Tammy','z','Rodriguez',49,'Female','001-952-761-6923x089','19850 Graham Path\nSouth Jason, IL 30300','tammy.rodriguez','ATR2O5StH(',13),('Jennifer','h','Archer',114,'Jennifer','U','Archer',53,'Male','001-609-508-8043x5963','Unit 8014 Box 8686\nDPO AE 22170','jennifer.archer','A1F1HiaGk!',14),('Michael','S','Frazier',115,'Michael','j','Frazier',26,'Female','966-931-8109x243','5692 Kimberly Lights Suite 111\nGuerratown, ID 82163','michael.frazier','Bk#!)Lv_@7',15),('Mary','p','Parsons',116,'Mary','E','Parsons',32,'Male','600.312.7845x33312','1306 Mitchell Plains Apt. 815\nLouismouth, UT 27570','mary.parsons','WkL5FWrx#^',16),('Rachel','N','Murray',117,'Rachel','d','Murray',22,'Female','861.429.1224','1215 Horn Key\nNew Derrick, MA 18046','rachel.murray','(2KSCmw_vZ',17),('Stephen','l','Chen',118,'Stephen','l','Chen',45,'Female','001-329-343-3737x43604','99085 Vanessa Points Apt. 752\nChadton, MA 80871','stephen.chen','$^L4YvQrmo',18),('Angela','r','Yates',119,'Angela','i','Yates',54,'Male','(955)404-4186','USS Gonzalez\nFPO AE 87584','angela.yates','LT+2CM*dws',19),('David','e','Mann',120,'David','t','Mann',32,'Female','001-219-694-9256x48729','5980 Holly Course\nChristytown, VT 24809','david.mann','0BoIG!Zp^*',20),('Cindy','O','Wood',121,'Cindy','u','Wood',26,'Male','001-300-611-0949x94940','51999 Jackson Forge Suite 012\nNew James, VI 42029','cindy.wood','(#Wz6VvN1o',21),('Rachel','t','Roberts',122,'Rachel','t','Roberts',51,'Female','481-708-5074','987 David Trail Suite 807\nNorth David, NC 50278','rachel.roberts','4+39&Zl8b_',22),('Jesus','C','Smith',123,'Jesus','I','Smith',33,'Female','001-486-493-0674','01444 Anne Bypass\nLake Markland, UT 85623','jesus.smith','X@a90eSvi_',23),('Connie','P','Adams',124,'Connie','y','Adams',32,'Female','-10406','330 Bryant Greens Apt. 205\nAshleystad, MA 96537','connie.adams','hR3D8UkAg)',24),('Allison','C','Foster',125,'Allison','b','Foster',37,'Female','+1-877-423-7954x9511','6740 Margaret Pine\nNew Markhaven, CO 76926','allison.foster','5@1t6Q5M4b',25),('Jeffrey','O','White',126,'Jeffrey','d','White',47,'Female','6794629342','Unit 0558 Box 2845\nDPO AE 29655','jeffrey.white',')%fX7NjS0U',26),('Richard','M','Santos',127,'Richard','J','Santos',58,'Male','001-628-675-6891x087','263 Castillo Terrace\nEast Ashleyburgh, PA 14583','richard.santos','R(D6Xhtz_a',27),('Jennifer','f','Stanley',128,'Jennifer','X','Stanley',49,'Male','825.320.9852x78016','217 Eric Islands\nMontgomeryhaven, UT 05281','jennifer.stanley','sii8$C)o0_',28),('Jessica','N','Richardson',129,'Jessica','k','Richardson',53,'Female','729-540-7135x17678','11570 Smith Oval\nNorth Raymond, IN 98068','jessica.richardson','T)a1Qh3pcs',29),('Shane','m','Patel',130,'Shane','u','Patel',47,'Male','001-421-781-5221x5534','827 Scott Lights\nPricechester, OH 96291','shane.patel','V1)Sdirk#Q',30),('Daniel','t','Moyer',131,'Daniel','L','Moyer',43,'Male','913-811-7155x9127','612 Dawn Ways Suite 543\nKevinview, KY 66545','daniel.moyer','P#71PIxx0z',31),('Cynthia','V','Hurley',132,'Cynthia','S','Hurley',24,'Female','770.397.7772','80121 Patrick Knoll Apt. 614\nMurphyfort, ND 72804','cynthia.hurley','!B6IdM1r_W',32),('John','Z','Gilbert',133,'John','V','Gilbert',31,'Female','732.475.6277x0847','0806 Smith Station Apt. 746\nJeffreyville, AS 67022','john.gilbert','Y1iTiubo)7',33),('Sarah','E','Mccoy',134,'Sarah','N','Mccoy',28,'Female','+1-399-315-4346x709','978 Rogers Radial\nPatriciamouth, NY 39525','sarah.mccoy','*7tWwI1i4o',34),('Mary','M','Thompson',135,'Mary','h','Thompson',30,'Female','(258)869-8385x7516','1120 Nathan Valley\nMarkville, WI 44957','mary.thompson','!*)8SHtOYo',35),('Michael','V','Cardenas',136,'Michael','D','Cardenas',59,'Female','244.938.2381','1181 Melinda Park Apt. 032\nFrankland, WV 84994','michael.cardenas','m9+i0KqvFa',36),('Stephanie','W','Hansen',137,'Stephanie','G','Hansen',35,'Female','906.354.3653','81917 Megan Branch Suite 817\nEast Jose, AL 37661','stephanie.hansen','1@&rIjZe@N',37),('Patricia','e','Brown',138,'Patricia','h','Brown',49,'Male','(726)271-4532x183','904 Wells Expressway\nGarciafort, VI 45634','patricia.brown','j1M22Fq7g(',38),('Laura','c','Long',139,'Laura','k','Long',36,'Female','(963)375-1401','529 Phillips Ville Suite 443\nNorth Kimberly, MO 65306','laura.long','$sq^P4BnA5',39),('Thuy',NULL,'Nguyen',200,NULL,NULL,NULL,NULL,NULL,'123444','123 street','nurse','nurse',41),('Nghi','','Hoang',99999,NULL,NULL,NULL,23,'Male','','','nghibien','nghibien',42);
/*!40000 ALTER TABLE `nurse` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-27 19:37:31
