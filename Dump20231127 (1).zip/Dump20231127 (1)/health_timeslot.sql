-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: health
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `timeslot`
--

DROP TABLE IF EXISTS `timeslot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `timeslot` (
  `idtimeslot` int NOT NULL AUTO_INCREMENT,
  `numOfPeople` int NOT NULL,
  `dateinfo` varchar(45) COLLATE utf8mb4_general_ci NOT NULL,
  `numOfNurse` int unsigned NOT NULL,
  PRIMARY KEY (`idtimeslot`),
  UNIQUE KEY `datetime_UNIQUE` (`dateinfo`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `timeslot`
--

LOCK TABLES `timeslot` WRITE;
/*!40000 ALTER TABLE `timeslot` DISABLE KEYS */;
INSERT INTO `timeslot` VALUES (12,12,'2023-11-19 9:00',12),(13,10,'2023-11-19 8:00',10),(14,25,'2023-11-29 9:00',12),(15,15,'2023-11-29 10:00',12),(16,5,'2023-11-29 12:00',1),(17,100,'2023-11-29 13:00',1),(18,1,'2023-11-28 12:00',1),(19,1,'2023-11-30 11:00',4),(20,1,'2023-11-28 15:00',1),(21,0,'2023-11-27 12:00',1),(22,1,'2023-11-27 11:00',1),(23,0,'2023-11-30 8:00',2),(24,0,'2023-12-07 11:00',1),(25,0,'2023-11-29 ',1),(26,1,'2023-11-28 11:00',2),(27,0,'2023-11-28 14:00',1),(28,0,'2023-11-28 17:00',5),(29,0,'2023-11-29 19:00',1),(30,0,'2023-11-29 14:00',1),(31,0,'2023-11-30 14:00',1);
/*!40000 ALTER TABLE `timeslot` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-27 19:37:30
